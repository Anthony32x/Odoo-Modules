Letter Management
=================

Using this module you can track Incoming / Outgoing letters, parcels,
registered documents or any other paper documents that are important for your
company to keep track of.

Credits
=======

Contributors
------------

* Holger Brunn <hbrunn@therp.nl>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Parthiv Patel, Tech Receptives (Original 6.0 Author)

Icon
----

http://commons.wikimedia.org/wiki/File:Kontact_Oxygen.svg

Maintainer
----------

.. image:: http://odoo-community.org/logo.png
   :alt: Odoo Community Association
   :target: http://odoo-community.org

This module is maintained by the OCA.

OCA, or the Odoo Community Association, is a nonprofit organization whose mission is to support the collaborative development of Odoo features and promote its widespread use.

To contribute to this module, please visit http://odoo-community.org.

